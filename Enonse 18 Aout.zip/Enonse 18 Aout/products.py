pwodwi_1 = {"name": "Chemiz", "price": 500, "quantity": 15}
pwodwi_2 = {"name": "Pantalon", "price": 300, "quantity": 25}
pwodwi_3 = {"name": "Tenis", "price": 2500, "quantity": 18}
lis_pwodwi = [pwodwi_1, pwodwi_2, pwodwi_3]
def afiche_pwodwi():
    for i in lis_pwodwi:
        print(i)
afiche_pwodwi()

