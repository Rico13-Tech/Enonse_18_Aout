import products

print("-------------------Rico_Store--------------")
def afiche_meni():
    print("Byenvini nan Rico-Store!")
    print("Chwazi yon nan atik saa yo:")
    print("1. Afiche enfòmasyon sou itilizatè yo")
    print("2. Fè yon kalkil")
    print("3. Sòti")
afiche_meni()

